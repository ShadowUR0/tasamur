# Tasamur symbol — strict geometry cleanup v2

## Result

This pass uses the previous cleaned SVG as the geometry source. It does not retrace the raster screenshot, and the previous SVG remains untouched. The production output keeps `viewBox="0 0 162.8 158.973"` and **#0A7780**.

## Reconstructed geometry

- All four **outer sweeping boundaries** were rebuilt from 4 cubics each to **2 broad cubics each**.
- All four **inner negative-space boundaries** were rebuilt from 4 cubics each to **1 cubic each**.
- Straight seam edges remain exact lines.
- Sharp outer tips remain sharp.
- Every outer tip and every endpoint controlling the central negative space is numerically unchanged.

The measured source supports two exact-looking **180-degree repeated pairs**, rather than forcing new 90-degree symmetry. Opposite outer modules 0↔3 differ by only **0.0017** normalized maximum and 1↔2 by **0.0069**, while adjacent 0↔1 differs by up to **0.0431**. I therefore normalized the opposite pairs and preserved the larger adjacent macro difference instead of redesigning it away.

## Complexity

- Cubic segments: **32 → 12**
- Anchor points: **40 → 20**
- Bezier control points: **64 → 24**
- Explicit straight segments: **4 → 4**, plus four closing straight edges

That removes **62.5%** of the cubic segments and **50.0%** of the anchors.

## Curve cleanup

The two outer spans are deliberate macro-spans. A one-cubic replacement visibly erased the broad shoulder of the existing logo; two spans retain that large gesture without keeping the previous local wobble. Their joins have aligned tangents and matched geometric curvature, so there is no join kink.

Each inner boundary is now one convex quarter-turn cubic, with no internal joins or secondary ripple. Its handles are tangent to the adjacent straight seams.

Deviation from the previous clean SVG is confined to curve interiors:

- Outer: mean bidirectional **0.415** SVG units; max **0.997**.
- Inner: mean bidirectional **0.558** SVG units; max **1.522**.

## Raster checks

| Width | IoU | XOR px | Alpha MAE |
|---:|---:|---:|---:|
| 16 | 0.991736 | 1 | 2.215 |
| 24 | 0.961538 | 9 | 2.346 |
| 32 | 0.986577 | 6 | 2.616 |
| 48 | 0.974648 | 27 | 2.623 |
| 64 | 0.981193 | 35 | 2.788 |
| 128 | 0.974926 | 186 | 2.879 |
| 256 | 0.975082 | 739 | 2.941 |
| 512 | 0.974741 | 3001 | 2.986 |

Small-size IoU can move sharply from only a few edge pixels; the XOR count is included for that reason.

## Validation

- XML parse: **PASS**
- CairoSVG at all requested sizes: **PASS**
- ImageMagick: **PASS**
- Chromium headless: **not available**
- Raster embedding / masks / filters / transforms: **none**

## Diagnostics

- `tasamur-strict-v2-overlay-8x.png`: gray overlap, magenta previous-only, cyan v2-only.
- `tasamur-strict-v2-difference-8x.png`: amplified 4096px alpha difference.
- `tasamur-strict-v2-before-after-4x.png`: previous clean left, strict v2 right.
- `tasamur-strict-v2-vector-overlay.svg`: infinite-zoom vector outline comparison.
